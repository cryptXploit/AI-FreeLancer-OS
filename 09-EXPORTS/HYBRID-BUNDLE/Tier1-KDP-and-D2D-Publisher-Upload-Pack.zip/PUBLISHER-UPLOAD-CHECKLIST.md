# Publisher Upload Checklist — Amazon KDP & Draft2Digital (Tier 1 Retail Pack)

This archive contains the complete, verified master files for publishing **Tier 1 (Essential Edition)** on **Amazon Kindle Direct Publishing (KDP)** and **Draft2Digital (D2D)**.

1. **Amazon KDP Kindle eBook ($9.99 USD):** `the-ai-freelancer-os.epub` + `kdp-ebook-and-d2d-cover.png` (`1600 x 2560 px`).
2. **Amazon KDP 6.0" x 9.0" Print Paperback ($16.99 USD):** `the-ai-freelancer-os-kdp-paperback-6x9.pdf` (`146 pages`) + `kdp-paperback-full-wrap-cover.pdf` (`12.58" x 9.25"`).
3. **Draft2Digital Wide Distribution ($9.99 USD):** `the-ai-freelancer-os.epub` + `kdp-ebook-and-d2d-cover.png`.
4. **Master Listing Copy & Bangladesh 10% Tax Treaty Runbook:** `marketplace-listings-and-bd-launch-runbook.md`.
