# Publisher Upload Checklist — Amazon KDP & Draft2Digital (Tier 1 Retail Pack)

This archive contains the complete, verified master files for publishing **Tier 1 (Essential Edition)** on **Amazon Kindle Direct Publishing (KDP)** and **Draft2Digital (D2D)**.

## File Mapping for Upload
1. **Amazon KDP Kindle eBook ($9.99 USD — 70% Royalty Plan):**
   - Interior File: `the-ai-freelancer-os.epub`
   - Cover Image: `kdp-ebook-and-d2d-cover.png` (`1600 x 2560 px`)
2. **Amazon KDP 6.0" x 9.0" Print Paperback ($16.99 USD — 60% Royalty Rate):**
   - Interior Print PDF: `the-ai-freelancer-os-kdp-paperback-6x9.pdf` (`146 pages`, B&W White Paper, No Bleed)
   - Full-Wrap Print Cover PDF: `kdp-paperback-full-wrap-cover.pdf` (`12.58" x 9.25"` @ 300 DPI, `0.33"` spine)
3. **Draft2Digital Wide Distribution ($9.99 USD — Apple Books, Kobo, B&N, Everand, Public Libraries):**
   - eBook File: `the-ai-freelancer-os.epub`
   - Cover Image: `kdp-ebook-and-d2d-cover.png`
   - Storefront Rule: Enable all retail and library channels EXCEPT Amazon.
4. **Master Listing Copy & Bangladesh 10% Tax Treaty Runbook:**
   - Open `marketplace-listings-and-bd-launch-runbook.md` for copy-paste HTML descriptions, 7 backend keywords, BISAC categories, Payoneer US receiving account setup, and IRS Form W-8BEN instructions.
